import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { Resend } from "resend"

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies()

    const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
          } catch {
            // Handle errors in setting cookies
          }
        },
      },
    })

    const body = await request.json()

    if (!body.email || !body.whatsappNumber) {
      return NextResponse.json({ error: "البريد الإلكتروني ورقم الواتس مطلوب" }, { status: 400 })
    }

    // Insert data into brands table
    const { data, error } = await supabase
      .from("brands")
      .insert([
        {
          email: body.email,
          whatsapp_number: body.whatsappNumber || null,
          facebook_link: body.facebookLink || null,
          instagram_link: body.instagramLink || null,
          tiktok_link: body.tiktokLink || null,
          website_link: body.websiteLink || null,
          cash_deposit: body.cashDeposit,
          e_wallet: body.eWallet,
          vodafone_cash_number: body.vodafoneCashNumber || null,
          vodafone_cash: body.vodafoneCash,
          orange_money_number: body.orangeMoneyNumber || null,
          orange_money: body.orangeMoney,
          etisalat_cash_number: body.etisalatCashNumber || null,
          etisalat_cash: body.etisalatCash,
          we_pay_number: body.wePayNumber || null,
          we_pay: body.wePay,
          paymob: body.paymob,
          paymob_account: body.paymobAccount || null,
          payment_gateway: body.paymentGateway,
          payment_account: body.paymentAccount || null,
          paypal: body.paypal,
          paypal_account: body.paypalAccount || null,
          notes: body.notes || null,
        },
      ])
      .select()

    if (error) {
      console.error("Supabase error:", error)
      return NextResponse.json({ error: "خطأ في حفظ البيانات" }, { status: 500 })
    }

    const emailContent = `
      <div dir="rtl" style="font-family: Arial, sans-serif; padding: 20px; background-color: #f5f5f5; border-radius: 8px;">
        <h2 style="color: #333; text-align: right; border-bottom: 2px solid #007bff; padding-bottom: 10px;">
          نموذج بيانات براند جديد
        </h2>
        
        <div style="background-color: white; padding: 20px; border-radius: 6px; margin-top: 15px;">
          <h3 style="color: #007bff; text-align: right; margin-top: 0;">1. بيانات التواصل</h3>
          <p><strong>البريد الإلكتروني:</strong> ${body.email}</p>
          <p><strong>رقم واتساب:</strong> ${body.whatsappNumber || "لم يتم التحديد"}</p>
          
          <h3 style="color: #007bff; text-align: right;">2. حسابات السوشيال ميديا</h3>
          <p><strong>فيسبوك:</strong> ${body.facebookLink || "لم يتم التحديد"}</p>
          <p><strong>إنستجرام:</strong> ${body.instagramLink || "لم يتم التحديد"}</p>
          <p><strong>تيك توك:</strong> ${body.tiktokLink || "لم يتم التحديد"}</p>
          <p><strong>موقع إلكتروني:</strong> ${body.websiteLink || "لم يتم التحديد"}</p>
          
          <h3 style="color: #007bff; text-align: right;">3. خدمات الدفع المتاحة</h3>
          <p><strong>إيداع نقدي:</strong> ${body.cashDeposit ? "نعم" : "لا"}</p>
          <p><strong>محافظ إلكترونية:</strong> ${body.eWallet ? "نعم" : "لا"}</p>
          ${body.vodafoneCash ? `<p style="margin-right: 20px;"><strong>Vodafone Cash:</strong> ${body.vodafoneCashNumber || "لم يتم التحديد"}</p>` : ""}
          ${body.orangeMoney ? `<p style="margin-right: 20px;"><strong>Orange Money:</strong> ${body.orangeMoneyNumber || "لم يتم التحديد"}</p>` : ""}
          ${body.etisalatCash ? `<p style="margin-right: 20px;"><strong>Etisalat Cash:</strong> ${body.etisalatCashNumber || "لم يتم التحديد"}</p>` : ""}
          ${body.wePay ? `<p style="margin-right: 20px;"><strong>WE Pay:</strong> ${body.wePayNumber || "لم يتم التحديد"}</p>` : ""}
          
          <h3 style="color: #007bff; text-align: right;">4. بوابات الدفع الإلكتروني</h3>
          ${body.paymob ? `<p><strong>Paymob:</strong> ${body.paymobAccount || "لم يتم التحديد"}</p>` : ""}
          ${body.paymentGateway ? `<p><strong>Payment:</strong> ${body.paymentAccount || "لم يتم التحديد"}</p>` : ""}
          ${body.paypal ? `<p><strong>PayPal:</strong> ${body.paypalAccount || "لم يتم التحديد"}</p>` : ""}
          
          <h3 style="color: #007bff; text-align: right;">5. ملاحظات إضافية</h3>
          <p>${body.notes || "لا توجد ملاحظات"}</p>
        </div>
        
        <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
          <p>تم إرسال هذه الرسالة تلقائياً من نموذج بيانات البراند</p>
        </div>
      </div>
    `

    try {
      await resend.emails.send({
        from: "noreply@resend.dev",
        to: "zoka657601@gmail.com",
        subject: `بيانات براند جديد: ${body.email}`,
        html: emailContent,
      })
    } catch (emailError) {
      console.error("Email sending error:", emailError)
      // Don't fail the request if email fails, still return success
    }

    return NextResponse.json({ success: true, data }, { status: 201 })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "خطأ في معالجة الطلب" }, { status: 500 })
  }
}
