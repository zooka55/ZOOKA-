"use client"
import Image from "next/image"
import BrandForm from "@/components/brand-form"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-black py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <Image src="/logo.png" alt="ZOOKA Express" width={180} height={120} className="h-auto" priority />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">
            <span className="text-blue-400">ZOOKA</span> نماذج
          </h1>
          <p className="text-lg text-blue-200">أضف بيانات عملك أو نشاطك التجاري</p>
          <div className="h-1 w-24 bg-gradient-to-r from-blue-500 to-orange-500 mx-auto mt-4 rounded-full"></div>
        </div>

        <BrandForm />
      </div>
    </div>
  )
}
