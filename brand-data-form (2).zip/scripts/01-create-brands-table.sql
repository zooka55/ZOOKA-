-- Create brands table to store business/brand data
CREATE TABLE IF NOT EXISTS brands (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) NOT NULL,
  whatsapp_number VARCHAR(20),
  facebook_link VARCHAR(500),
  instagram_link VARCHAR(500),
  tiktok_link VARCHAR(500),
  website_link VARCHAR(500),
  cash_deposit BOOLEAN DEFAULT FALSE,
  e_wallet BOOLEAN DEFAULT FALSE,
  vodafone_cash BOOLEAN DEFAULT FALSE,
  orange_money BOOLEAN DEFAULT FALSE,
  etisalat_cash BOOLEAN DEFAULT FALSE,
  we_pay BOOLEAN DEFAULT FALSE,
  wallet_number VARCHAR(50),
  paymob BOOLEAN DEFAULT FALSE,
  payment_gateway BOOLEAN DEFAULT FALSE,
  paypal BOOLEAN DEFAULT FALSE,
  payment_account_email VARCHAR(255),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_brands_email ON brands(email);
