"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

export default function BrandForm() {
  const [isLoading, setIsLoading] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [errorMessage, setErrorMessage] = useState("")

  const [formData, setFormData] = useState({
    email: "",
    whatsappNumber: "",
    facebookLink: "",
    instagramLink: "",
    tiktokLink: "",
    websiteLink: "",
    cashDeposit: false,
    eWallet: false,
    vodafoneCashNumber: "",
    vodafoneCash: false,
    orangeMoneyNumber: "",
    orangeMoney: false,
    etisalatCashNumber: "",
    etisalatCash: false,
    wePayNumber: "",
    wePay: false,
    paymobAccount: "",
    paymob: false,
    paymentAccount: "",
    paymentGateway: false,
    paypalAccount: "",
    paypal: false,
    notes: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? (e.target as HTMLInputElement).checked : value,
    }))
  }

  const handleCheckboxChange = (field: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: !prev[field as keyof typeof formData],
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setErrorMessage("")
    setSuccessMessage("")

    if (!formData.email || !formData.whatsappNumber) {
      setErrorMessage("البريد الإلكتروني ورقم الواتس مطلوب!")
      setIsLoading(false)
      return
    }

    try {
      const response = await fetch("/api/brands", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          vodafoneCashNumber: formData.vodafoneCashNumber,
          orangeMoneyNumber: formData.orangeMoneyNumber,
          etisalatCashNumber: formData.etisalatCashNumber,
          wePayNumber: formData.wePayNumber,
          paymobAccount: formData.paymobAccount,
          paymentAccount: formData.paymentAccount,
          paypalAccount: formData.paypalAccount,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "حدث خطأ ما")
      }

      setSuccessMessage("تم حفظ البيانات بنجاح وإرسال الإشعار إلى البريد الإلكتروني!")
      setFormData({
        email: "",
        whatsappNumber: "",
        facebookLink: "",
        instagramLink: "",
        tiktokLink: "",
        websiteLink: "",
        cashDeposit: false,
        eWallet: false,
        vodafoneCashNumber: "",
        vodafoneCash: false,
        orangeMoneyNumber: "",
        orangeMoney: false,
        etisalatCashNumber: "",
        etisalatCash: false,
        wePayNumber: "",
        wePay: false,
        paymobAccount: "",
        paymob: false,
        paymentAccount: "",
        paymentGateway: false,
        paypalAccount: "",
        paypal: false,
        notes: "",
      })

      setTimeout(() => setSuccessMessage(""), 3000)
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "خطأ في حفظ البيانات")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4 rtl">
      {successMessage && (
        <div className="bg-green-900/30 border border-green-500/50 text-green-300 px-4 py-3 rounded-lg backdrop-blur-sm">
          {successMessage}
        </div>
      )}
      {errorMessage && (
        <div className="bg-red-900/30 border border-red-500/50 text-red-300 px-4 py-3 rounded-lg backdrop-blur-sm">
          {errorMessage}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Contact Information */}
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:border-blue-500/30 transition-colors">
          <CardHeader>
            <CardTitle className="text-right text-blue-300">1️⃣ بيانات التواصل</CardTitle>
            <CardDescription className="text-right text-slate-400">أضف بيانات التواصل الخاصة بك</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="email" className="text-right block mb-2 text-slate-200">
                البريد الإلكتروني (Email) *
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={handleInputChange}
                placeholder="example@email.com"
                className="text-right bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <div>
              <Label htmlFor="whatsappNumber" className="text-right block mb-2 text-slate-200">
                رقم واتساب أعمال *
              </Label>
              <Input
                id="whatsappNumber"
                name="whatsappNumber"
                type="tel"
                required
                value={formData.whatsappNumber}
                onChange={handleInputChange}
                placeholder="+20 1234567890"
                className="text-right bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
          </CardContent>
        </Card>

        {/* Social Media */}
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:border-blue-500/30 transition-colors">
          <CardHeader>
            <CardTitle className="text-right text-blue-300">2️⃣ حسابات السوشيال ميديا</CardTitle>
            <CardDescription className="text-right text-slate-400">
              لينك حساباتك على مواقع التواصل (اختياري)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="facebookLink" className="text-right block mb-2 text-slate-200">
                فيسبوك
              </Label>
              <Input
                id="facebookLink"
                name="facebookLink"
                type="url"
                value={formData.facebookLink}
                onChange={handleInputChange}
                placeholder="https://facebook.com/..."
                className="text-right bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <div>
              <Label htmlFor="instagramLink" className="text-right block mb-2 text-slate-200">
                إنستجرام
              </Label>
              <Input
                id="instagramLink"
                name="instagramLink"
                type="url"
                value={formData.instagramLink}
                onChange={handleInputChange}
                placeholder="https://instagram.com/..."
                className="text-right bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <div>
              <Label htmlFor="tiktokLink" className="text-right block mb-2 text-slate-200">
                تيك توك
              </Label>
              <Input
                id="tiktokLink"
                name="tiktokLink"
                type="url"
                value={formData.tiktokLink}
                onChange={handleInputChange}
                placeholder="https://tiktok.com/..."
                className="text-right bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <div>
              <Label htmlFor="websiteLink" className="text-right block mb-2 text-slate-200">
                موقع إلكتروني (إن وجد)
              </Label>
              <Input
                id="websiteLink"
                name="websiteLink"
                type="url"
                value={formData.websiteLink}
                onChange={handleInputChange}
                placeholder="https://example.com"
                className="text-right bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
          </CardContent>
        </Card>

        {/* Cash and E-Wallets */}
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:border-blue-500/30 transition-colors">
          <CardHeader>
            <CardTitle className="text-right text-blue-300">3️⃣ خدمات الدفع المتاحة</CardTitle>
            <CardDescription className="text-right text-slate-400">اختر الخيارات المتاحة</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <Label className="text-right block font-semibold text-slate-200">
                الإيداع النقدي والمحافظ الإلكترونية
              </Label>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="cashDeposit"
                    checked={formData.cashDeposit}
                    onCheckedChange={() => handleCheckboxChange("cashDeposit")}
                  />
                  <Label htmlFor="cashDeposit" className="cursor-pointer text-slate-300">
                    إيداع نقدي
                  </Label>
                </div>
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="eWallet"
                    checked={formData.eWallet}
                    onCheckedChange={() => handleCheckboxChange("eWallet")}
                  />
                  <Label htmlFor="eWallet" className="cursor-pointer text-slate-300">
                    محافظ إلكترونية
                  </Label>
                </div>
              </div>
            </div>

            {formData.eWallet && (
              <div className="space-y-4 bg-slate-900/30 p-4 rounded-lg border border-slate-700">
                <Label className="text-right block font-semibold text-sm text-slate-200">المحافظ المدعومة</Label>

                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="vodafoneCash"
                      checked={formData.vodafoneCash}
                      onCheckedChange={() => handleCheckboxChange("vodafoneCash")}
                    />
                    <Label htmlFor="vodafoneCash" className="cursor-pointer text-slate-300">
                      Vodafone Cash (010)
                    </Label>
                  </div>
                  {formData.vodafoneCash && (
                    <Input
                      name="vodafoneCashNumber"
                      type="tel"
                      value={formData.vodafoneCashNumber}
                      onChange={handleInputChange}
                      placeholder="+20 10XXXXXXXXX"
                      className="text-right bg-slate-800/70 border-slate-600 text-white placeholder:text-slate-500 mr-6"
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="orangeMoney"
                      checked={formData.orangeMoney}
                      onCheckedChange={() => handleCheckboxChange("orangeMoney")}
                    />
                    <Label htmlFor="orangeMoney" className="cursor-pointer text-slate-300">
                      Orange Money (012)
                    </Label>
                  </div>
                  {formData.orangeMoney && (
                    <Input
                      name="orangeMoneyNumber"
                      type="tel"
                      value={formData.orangeMoneyNumber}
                      onChange={handleInputChange}
                      placeholder="+20 12XXXXXXXXX"
                      className="text-right bg-slate-800/70 border-slate-600 text-white placeholder:text-slate-500 mr-6"
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="etisalatCash"
                      checked={formData.etisalatCash}
                      onCheckedChange={() => handleCheckboxChange("etisalatCash")}
                    />
                    <Label htmlFor="etisalatCash" className="cursor-pointer text-slate-300">
                      Etisalat Cash (011)
                    </Label>
                  </div>
                  {formData.etisalatCash && (
                    <Input
                      name="etisalatCashNumber"
                      type="tel"
                      value={formData.etisalatCashNumber}
                      onChange={handleInputChange}
                      placeholder="+20 11XXXXXXXXX"
                      className="text-right bg-slate-800/70 border-slate-600 text-white placeholder:text-slate-500 mr-6"
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="wePay"
                      checked={formData.wePay}
                      onCheckedChange={() => handleCheckboxChange("wePay")}
                    />
                    <Label htmlFor="wePay" className="cursor-pointer text-slate-300">
                      WE Pay (015)
                    </Label>
                  </div>
                  {formData.wePay && (
                    <Input
                      name="wePayNumber"
                      type="tel"
                      value={formData.wePayNumber}
                      onChange={handleInputChange}
                      placeholder="+20 15XXXXXXXXX"
                      className="text-right bg-slate-800/70 border-slate-600 text-white placeholder:text-slate-500 mr-6"
                    />
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Payment Gateways */}
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:border-blue-500/30 transition-colors">
          <CardHeader>
            <CardTitle className="text-right text-blue-300">4️⃣ بوابات الدفع الإلكتروني</CardTitle>
            <CardDescription className="text-right text-slate-400">
              هل لديك حساب على أي من هذه البوابات؟
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="paymob"
                    checked={formData.paymob}
                    onCheckedChange={() => handleCheckboxChange("paymob")}
                  />
                  <Label htmlFor="paymob" className="cursor-pointer text-slate-300">
                    Paymob
                  </Label>
                </div>
                {formData.paymob && (
                  <Input
                    name="paymobAccount"
                    type="text"
                    value={formData.paymobAccount}
                    onChange={handleInputChange}
                    placeholder="البريد الإلكتروني أو رقم الحساب"
                    className="text-right bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500 mr-6"
                  />
                )}
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="paymentGateway"
                    checked={formData.paymentGateway}
                    onCheckedChange={() => handleCheckboxChange("paymentGateway")}
                  />
                  <Label htmlFor="paymentGateway" className="cursor-pointer text-slate-300">
                    Payment
                  </Label>
                </div>
                {formData.paymentGateway && (
                  <Input
                    name="paymentAccount"
                    type="text"
                    value={formData.paymentAccount}
                    onChange={handleInputChange}
                    placeholder="البريد الإلكتروني أو رقم الحساب"
                    className="text-right bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500 mr-6"
                  />
                )}
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="paypal"
                    checked={formData.paypal}
                    onCheckedChange={() => handleCheckboxChange("paypal")}
                  />
                  <Label htmlFor="paypal" className="cursor-pointer text-slate-300">
                    PayPal
                  </Label>
                </div>
                {formData.paypal && (
                  <Input
                    name="paypalAccount"
                    type="text"
                    value={formData.paypalAccount}
                    onChange={handleInputChange}
                    placeholder="البريد الإلكتروني أو رقم الحساب"
                    className="text-right bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500 mr-6"
                  />
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Additional Notes */}
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:border-blue-500/30 transition-colors">
          <CardHeader>
            <CardTitle className="text-right text-blue-300">5️⃣ ملاحظات إضافية</CardTitle>
            <CardDescription className="text-right text-slate-400">
              أي تفاصيل إضافية تود إضافتها (اختياري)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              name="notes"
              value={formData.notes}
              onChange={handleInputChange}
              placeholder="أضف أي ملاحظات إضافية هنا..."
              className="min-h-24 text-right bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-500"
            />
          </CardContent>
        </Card>

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={isLoading}
          className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white border-0 transition-all hover:shadow-lg hover:shadow-blue-500/50"
        >
          {isLoading ? "جاري الحفظ..." : "حفظ البيانات"}
        </Button>
      </form>
    </div>
  )
}
